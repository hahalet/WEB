export const env = 'release';
export const hosts = {
    dev:'http://106.75.141.103/aries/',
    release: 'https://newstartech.vn/aries/',
}
export const host = hosts[env]