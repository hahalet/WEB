import * as React from "react";
import { IntlProvider, FormattedMessage, FormattedNumber, injectIntl } from 'react-intl'
// import Swiper from 'swiper';
// import 'swiper/swiper.scss'
import './home.scss'
import Header from '../../components/header/header'
import Footer from '../../components/footer/footer'
import { images } from "../../utils/images";
import { withRouter } from "react-router";

export interface HomeProps { }

export interface HomeStateProps {

}

class Home extends React.Component<HomeProps, HomeStateProps, any> {
	constructor(props: any) {
		super(props)
	}
	state: HomeStateProps = {

	}

	componentDidMount = () => {

	}
	_renderTitle = (name, title) => {
		return (
			<div className="home_title_con">
				<img className="home_title_icon" src={images.home_title_icon} alt="" />
				<div>{title}</div>
				<div className="home_title_name">{name}</div>
			</div>

		)
	}
	render() {
		return <div className="homeBody">
			<Header isWhiteBg></Header>
			<div className="home_header">
				<div className="home_con_w">
					<div className="home_header_title">数字藏品管理系统</div>
					<div className="home_header_text">运用区块链技术,构建”区块链+”数字收藏服务生态,针对艺术收藏、潮玩手办、名贵艺术品等藏品市场推出了专业化的区块链解决方案</div>
					<div className="home_header_img_con">
						<img className="home_header_image" src={images.home_h_cc_icon} alt="" />
						<img className="home_header_image" src={images.home_h_manage_icon} alt="" />
						<img className="home_header_image" src={images.home_h_qu_icon} alt="" />
					</div>
				</div>
			</div>
			<div className="home_con">
				<div className="home_con_w">
					{this._renderTitle('F', '方案多样，服务全面')}
				</div>
				<div className="project">
					<div className="project_con">

					</div>
				</div>
			</div>
			<div className="unsplashContent">
				<div className="unsplashInfo">
					<div className="unsplashTitle">Về chúng tôi</div>
					<div>NewStar was established in Singapore in 2019. With the vision of “making financial services accessible”, we are committed to the exploration and innovation of financial technology fields such as big data and artificial intelligence. We always devote ourselves to connecting the world through technology, so that everyone in the world can enjoy equal financial and life services.</div>
					<img className="Group121" src={images.Group121} alt="" />
				</div>
				<img className="unsplash_QBpZGqEMsKg" src={images.unsplash_QBpZGqEMsKg} alt="" />
			</div>

			<div className="bxContent">
				<div className="bxImage bxImage1"></div>
				<div className="bxImage bxImage2"></div>
				<div className="bxImage bxImage3"></div>
			</div>

			<div className="VietNamContent">
				<div className="VietNam1">
					<img className="VietNam1Img1" src={images.image1} alt="image1" />
					<img className="VietNam1Img2" src={images.image2} alt="image2" />
					<div>
						<div className="VietNam1Text">
							<div className="VietNamL">
								Chi nhánh <span className="ChiLine"></span>
							</div>
							<div className="VietNamTitle">
								Việt Nam <img className="VietNamTitleImage" src={images.Group36} alt="" />
							</div>
							<div>Trụ sở chính: Tầng 4, Tòa Nhà Nhật An, 30D Kim Mã Thượng, Phường Cống Vị, Quận Ba Đình, Thành phố Hà Nội, Việt Nam</div>
							<div className="VietNam1MT">
								Văn phòng đại diện: CTM Complex, 139 đường Cầu Giấy, Quan Hoa, Cầu Giấy Hà Nội</div>
						</div>
						<img className="VietNam1Img3" src={images.image3} alt="image3" />
						<img className="VietNam1Img4" src={images.image4} alt="image4" />
					</div>
				</div>
				<div className="VietNam2">
					<img src={images.Group108} alt="Group108" />
					<div className="VietNam2Text">
						<div className="VietNam2Title">Đội ngũ tài năng trẻ với nhiệt huyết cao</div>
						<div className="VietNam2TextMB">
							Lorem ipsum dolor sit amet, consectetur adipiscing elit. Dignissim sit vulputate lectus bibendum ultricies. Neque a egestas vitae ac. Quam sit in facilisis sed. Nunc rutrum in natoque id imperdiet sed sed risus, sed.
						</div>
						<div>
							Tempus diam quis porta enim. Imperdiet tellus risus, in vitae quis. Non, tortor, in ullamcorper fermentum magna sem eget. Pellentesque sem gravida mauris, mattis non elementum libero.</div>
					</div>
				</div>
			</div>
			<Footer></Footer>
		</div>
	}
}

export default injectIntl(withRouter(Home) as any) as any