export default {
  home: 'Home',
  aboutUs: 'About Us',
};
