export default {
  home: 'Trang chủ',
  aboutUs: 'Về chúng tôi',
};