# NewStar 官网 （集体官网）

## npm i 下载依赖
## npm run start 项目运行
## npm run build 项目打包